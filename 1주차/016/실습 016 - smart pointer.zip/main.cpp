#include <iostream>
#include <memory>

using namespace std;
void update(int* a, int* b);

int main(){
    unique_ptr<int> ptr_a (new int);
    unique_ptr<int> ptr_b (new int);

    cin >> *ptr_a >> *ptr_b;

    update(ptr_a.get(), ptr_b.get());

    cout << *ptr_a << endl << *ptr_b << endl;

}



void update(int* a, int* b){

    int tmp = *a;
    *a = *a + *b;
    *b = tmp - *b;

}