#include <iostream>
#include <map>
#include <vector>
#include <utility>
#include <algorithm>
#include <regex>

using namespace std;

bool wordCompare(const pair<string,int> a, const pair<string,int> b){
    if (a.second == b.second)
        return a.first < b.first;
    return a.second > b.second;
}

int main() {
    map <string, int> words;

    string str;

    while (cin >> str && str != "^") {
        string re_str{regex_replace(str, regex("[.|,|:|;| ]"), "")};
        transform(re_str.begin(), re_str.end(), re_str.begin(), ::tolower);
        auto search = words.find(re_str);

        if (search != words.end())
            words[re_str]++;
        else
            words.insert({re_str, 1});
    }

    vector <string> find_vec;
    while (cin >> str && str != "QUIT"){
        string re_str {regex_replace(str, regex("[.|,|:|;| ]"), "")};
        transform(re_str.begin(), re_str.end(), re_str.begin(), ::tolower);

        find_vec.push_back(re_str);
    }

    vector <pair<string,int>> word_sorted(words.begin(), words.end());
    sort(word_sorted.begin(), word_sorted.end(), wordCompare);

    cout << "#Words: " << word_sorted.size() << endl;

    cout << "Top 5 Word Frequencies" << endl;
    cout << 1 << " " << word_sorted[0].first << ": " << word_sorted[0].second << endl;
    cout << 2 << " " << word_sorted[1].first << ": " << word_sorted[1].second << endl;
    cout << 3 << " " << word_sorted[2].first << ": " << word_sorted[2].second << endl;
    cout << 4 << " " << word_sorted[3].first << ": " << word_sorted[3].second << endl;
    cout << 5 << " " << word_sorted[4].first << ": " << word_sorted[4].second << endl;


    cout << "Find Word Frequencies" << endl;
    for (auto &i : find_vec){
        auto search = words.find(i);

        if (search != words.end())
            cout << search->first << ": " << search->second <<endl;
        else
            cout << i << ": " << 0 << endl;
    }
    cout << endl << "Bye!";

    return 0;
}